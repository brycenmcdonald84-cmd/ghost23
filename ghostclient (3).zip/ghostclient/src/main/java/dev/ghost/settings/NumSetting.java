package dev.ghost.settings;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public class NumSetting extends Setting {
    public double value;
    public final double min, max, step;

    public NumSetting(String name, double def, double min, double max, double step) {
        super(name);
        this.min = min; this.max = max; this.step = step;
        set(def);
    }

    public void set(double v) {
        v = Math.round((v - min) / step) * step + min;
        value = Math.max(min, Math.min(max, v));
    }

    public float f() { return (float) value; }
    @Override public JsonElement save() { return new JsonPrimitive(value); }
    @Override public void load(JsonElement e) { set(e.getAsDouble()); }
}
