package dev.ghost.gui;

import dev.ghost.*;
import dev.ghost.modules.Hud;
import dev.ghost.settings.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ClickGui extends Screen {
    private interface Action { void run(int button, double mouseX); }
    private record Hit(int x, int y, int w, int h, Action action) {}

    private static final int PW = 94, GAP = 5, HEADER = 16, ROW = 14, SROW = 12;
    private static final Set<Module> expanded = new HashSet<>();
    private static final Set<Category> collapsed = new HashSet<>();
    private final List<Hit> hits = new ArrayList<>();

    public ClickGui() { super(Text.literal("Ghost")); }

    @Override public boolean shouldPause() { return false; }
    @Override public void removed() { Config.save(); }

    private static boolean over(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        hits.clear();
        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        ctx.fill(0, 0, width, height, 0x88000000);

        int total = Category.values().length * PW + (Category.values().length - 1) * GAP;
        int x = Math.max(4, (width - total) / 2);
        int idx = 0;

        for (Category cat : Category.values()) {
            int y = 16;
            int accent = Hud.accent(idx * 4);
            ctx.fill(x, y, x + PW, y + HEADER, 0xFF101010);
            ctx.fill(x, y + HEADER - 1, x + PW, y + HEADER, accent);
            ctx.drawTextWithShadow(tr, cat.label, x + 4, y + 4, 0xFFFFFFFF);
            ctx.drawTextWithShadow(tr, collapsed.contains(cat) ? "+" : "-", x + PW - 10, y + 4, 0xFFAAAAAA);
            hits.add(new Hit(x, y, PW, HEADER, (b, m) -> {
                if (!collapsed.remove(cat)) collapsed.add(cat);
            }));
            y += HEADER;

            if (!collapsed.contains(cat)) {
                for (Module mod : GhostClient.MODULES) {
                    if (mod.category != cat) continue;

                    int bg = mod.isEnabled() ? ((accent & 0x00FFFFFF) | 0xAA000000) : 0xFF1A1A1A;
                    if (over(mx, my, x, y, PW, ROW)) bg = lighten(bg);
                    ctx.fill(x, y, x + PW, y + ROW, bg);
                    ctx.drawTextWithShadow(tr, mod.name, x + 4, y + 3, 0xFFFFFFFF);
                    if (!mod.settings.isEmpty()) {
                        ctx.drawTextWithShadow(tr, expanded.contains(mod) ? "v" : ">", x + PW - 10, y + 3, 0xFFAAAAAA);
                    }
                    hits.add(new Hit(x, y, PW, ROW, (b, m) -> {
                        if (b == 0) mod.toggle();
                        else if (b == 1 && !mod.settings.isEmpty()) {
                            if (!expanded.remove(mod)) expanded.add(mod);
                        }
                    }));
                    y += ROW;

                    if (expanded.contains(mod)) {
                        for (Setting s : mod.settings) {
                            final int sx = x;
                            int rowBg = over(mx, my, x, y, PW, SROW) ? 0xFF1C1C1C : 0xFF0E0E0E;
                            ctx.fill(x, y, x + PW, y + SROW, rowBg);

                            if (s instanceof BoolSetting bs) {
                                ctx.drawTextWithShadow(tr, bs.name, x + 6, y + 2, 0xFFDDDDDD);
                                String v = bs.value ? "ON" : "OFF";
                                ctx.drawTextWithShadow(tr, v, x + PW - 4 - tr.getWidth(v), y + 2,
                                    bs.value ? 0xFF55FF55 : 0xFFFF5555);
                                hits.add(new Hit(x, y, PW, SROW, (b, m) -> bs.value = !bs.value));
                            } else if (s instanceof NumSetting ns) {
                                int fill = (int) ((ns.value - ns.min) / (ns.max - ns.min) * PW);
                                ctx.fill(x, y, x + fill, y + SROW, (accent & 0x00FFFFFF) | 0x66000000);
                                ctx.drawTextWithShadow(tr, ns.name, x + 6, y + 2, 0xFFDDDDDD);
                                String v = ns.step >= 1 ? String.valueOf((int) ns.value) : String.format("%.2f", ns.value);
                                ctx.drawTextWithShadow(tr, v, x + PW - 4 - tr.getWidth(v), y + 2, 0xFFFFFFFF);
                                hits.add(new Hit(x, y, PW, SROW, (b, m) ->
                                    ns.set(ns.min + (m - sx) / PW * (ns.max - ns.min))));
                            } else if (s instanceof ModeSetting ms) {
                                ctx.drawTextWithShadow(tr, ms.name, x + 6, y + 2, 0xFFDDDDDD);
                                String v = ms.value();
                                ctx.drawTextWithShadow(tr, v, x + PW - 4 - tr.getWidth(v), y + 2, 0xFFFFFFFF);
                                hits.add(new Hit(x, y, PW, SROW, (b, m) -> ms.cycle(b == 1 ? -1 : 1)));
                            }
                            y += SROW;
                        }
                    }
                }
            }
            x += PW + GAP;
            idx++;
        }

        String tip = "Left click: toggle  |  Right click: settings  |  Click settings to change  |  Esc: close";
        ctx.drawTextWithShadow(tr, tip, (width - tr.getWidth(tip)) / 2, height - 14, 0xFF888888);
    }

    private static int lighten(int c) {
        int a = c >>> 24, r = Math.min(255, ((c >> 16) & 255) + 25),
            g = Math.min(255, ((c >> 8) & 255) + 25), b = Math.min(255, (c & 255) + 25);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        int mx = (int) click.x(), my = (int) click.y();
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (over(mx, my, h.x(), h.y(), h.w(), h.h())) {
                h.action().run(click.button(), click.x());
                return true;
            }
        }
        return super.mouseClicked(click, doubled);
    }
}
