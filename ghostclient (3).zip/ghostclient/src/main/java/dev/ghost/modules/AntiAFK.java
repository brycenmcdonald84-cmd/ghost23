package dev.ghost.modules;

import dev.ghost.*;
import dev.ghost.settings.*;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

public class AntiAFK extends Module {
    private final NumSetting interval = num("Seconds", 20, 5, 60, 1);
    private int ticks;
    private boolean flip;

    public AntiAFK() { super("AntiAFK", Category.PLAYER, GLFW.GLFW_KEY_UNKNOWN); }

    @Override protected void onEnable() { ticks = 0; }

    @Override
    public void onTick() {
        if (++ticks < interval.value * 20) return;
        ticks = 0;
        var p = mc.player;
        flip = !flip;
        p.setYaw(p.getYaw() + (flip ? 3f : -3f));
        p.swingHand(Hand.MAIN_HAND);
        if (p.isOnGround()) {
            Vec3d v = p.getVelocity();
            p.setVelocity(v.x, 0.42, v.z);
        }
    }
}
