package dev.ghost.modules;

import dev.ghost.*;
import org.lwjgl.glfw.GLFW;

public class Sprint extends Module {
    public Sprint() { super("Sprint", Category.MOVEMENT, GLFW.GLFW_KEY_R); }

    @Override
    public void onTick() {
        var p = mc.player;
        if (mc.options.forwardKey.isPressed() && !p.horizontalCollision && !p.isSneaking()
                && p.getHungerManager().getFoodLevel() > 6) {
            p.setSprinting(true);
        }
    }
}
