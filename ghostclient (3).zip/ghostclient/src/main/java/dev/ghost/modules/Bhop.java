package dev.ghost.modules;

import dev.ghost.*;
import dev.ghost.settings.*;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

public class Bhop extends Module {
    private final NumSetting height = num("Height", 0.42, 0.2, 0.6, 0.02);

    public Bhop() { super("Bhop", Category.MOVEMENT, GLFW.GLFW_KEY_UNKNOWN); }

    @Override
    public void onTick() {
        var p = mc.player;
        if (moving() && p.isOnGround() && !p.isSneaking()) {
            Vec3d v = p.getVelocity();
            p.setVelocity(v.x, height.value, v.z);
        }
    }
}
