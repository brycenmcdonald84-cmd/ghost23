package dev.ghost.modules;

import dev.ghost.*;
import dev.ghost.settings.*;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import org.lwjgl.glfw.GLFW;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

public class Hud extends Module {
    public static Hud INSTANCE;

    private final BoolSetting watermark = bool("Watermark", true);
    private final ModeSetting clientName = mode("Name", "Ghost", "Phantom", "Spectre", "Wraith", "Specter");
    private final BoolSetting moduleList = bool("ModuleList", true);
    private final BoolSetting coords = bool("Coords", true);
    private final BoolSetting fps = bool("FPS", true);
    private final ModeSetting color = mode("Color", "Green", "Blue", "Purple", "Red", "Rainbow");

    public Hud() {
        super("HUD", Category.RENDER, GLFW.GLFW_KEY_UNKNOWN);
        INSTANCE = this;
        visible = false;
        persistEnabled = true;
        setEnabledSilently(true);
    }

    public static int accent(int index) {
        if (INSTANCE == null) return 0xFF55FF55;
        return switch (INSTANCE.color.value()) {
            case "Blue" -> 0xFF55AAFF;
            case "Purple" -> 0xFFAA55FF;
            case "Red" -> 0xFFFF5555;
            case "Rainbow" -> Color.HSBtoRGB(((System.currentTimeMillis() / 20 + index * 12L) % 360) / 360f, 0.65f, 1f) | 0xFF000000;
            default -> 0xFF55FF55;
        };
    }

    public void render(DrawContext ctx) {
        if (!isEnabled()) return;
        TextRenderer tr = mc.textRenderer;
        int y = 4;

        if (watermark.value) {
            ctx.drawTextWithShadow(tr, clientName.value(), 4, y, accent(0));
            y += 11;
        }
        if (coords.value && mc.player != null) {
            String s = String.format("XYZ: %.1f %.1f %.1f", mc.player.getX(), mc.player.getY(), mc.player.getZ());
            ctx.drawTextWithShadow(tr, s, 4, y, 0xFFFFFFFF);
            y += 10;
        }
        if (fps.value) {
            ctx.drawTextWithShadow(tr, mc.getCurrentFps() + " FPS", 4, y, 0xFFFFFFFF);
        }

        if (moduleList.value) {
            List<Module> on = new ArrayList<>();
            for (Module m : GhostClient.MODULES) if (m.isEnabled() && m.visible) on.add(m);
            on.sort((a, b) -> tr.getWidth(b.name) - tr.getWidth(a.name));
            int sw = ctx.getScaledWindowWidth();
            int ry = 4, i = 0;
            for (Module m : on) {
                int w = tr.getWidth(m.name);
                ctx.fill(sw - w - 8, ry - 1, sw - 2, ry + 10, 0x66000000);
                ctx.fill(sw - 3, ry - 1, sw - 2, ry + 10, accent(i));
                ctx.drawTextWithShadow(tr, m.name, sw - w - 6, ry, accent(i));
                ry += 11;
                i++;
            }
        }
    }
}
