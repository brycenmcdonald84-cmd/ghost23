package dev.ghost.modules;

import dev.ghost.*;
import dev.ghost.settings.*;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

public class Speed extends Module {
    private final NumSetting mult = num("Multiplier", 1.35, 1.0, 4.0, 0.05);
    private final BoolSetting groundOnly = bool("GroundOnly", true);

    public Speed() { super("Speed", Category.MOVEMENT, GLFW.GLFW_KEY_V); }

    @Override
    public void onTick() {
        var p = mc.player;
        if (!moving() || p.isSneaking() || p.isTouchingWater()) return;
        if (groundOnly.value && !p.isOnGround()) return;
        Vec3d v = p.getVelocity();
        p.setVelocity(v.x * mult.value, v.y, v.z * mult.value);
    }
}
