package dev.ghost.modules;

import dev.ghost.*;
import dev.ghost.settings.*;
import net.minecraft.entity.Entity;
import org.lwjgl.glfw.GLFW;

import java.util.HashSet;
import java.util.Set;

/** Highlights entities through walls using the client-side glowing outline. */
public class ESP extends Module {
    private final NumSetting range = num("Range", 64, 16, 128, 4);
    private final BoolSetting players = bool("Players", true);
    private final BoolSetting mobs = bool("Mobs", true);
    private final BoolSetting animals = bool("Animals", false);
    private final Set<Integer> glowing = new HashSet<>();

    public ESP() { super("ESP", Category.RENDER, GLFW.GLFW_KEY_UNKNOWN); }

    @Override
    public void onTick() {
        var p = mc.player;
        double r2 = range.value * range.value;
        for (Entity e : mc.world.getEntities()) {
            boolean want = Targets.valid(e, players.value, mobs.value, animals.value) && p.squaredDistanceTo(e) <= r2;
            if (want) { e.setGlowing(true); glowing.add(e.getId()); }
            else if (glowing.remove(e.getId())) e.setGlowing(false);
        }
    }

    @Override
    protected void onDisable() {
        if (mc.world != null) {
            for (int id : glowing) {
                Entity e = mc.world.getEntityById(id);
                if (e != null) e.setGlowing(false);
            }
        }
        glowing.clear();
    }
}
