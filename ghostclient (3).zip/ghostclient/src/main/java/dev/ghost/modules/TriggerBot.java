package dev.ghost.modules;

import dev.ghost.*;
import dev.ghost.settings.*;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import org.lwjgl.glfw.GLFW;

public class TriggerBot extends Module {
    private final NumSetting charge = num("Charge", 1.0, 0.5, 1.0, 0.05);
    private final BoolSetting players = bool("Players", true);
    private final BoolSetting mobs = bool("Mobs", true);
    private final BoolSetting animals = bool("Animals", false);

    public TriggerBot() { super("TriggerBot", Category.COMBAT, GLFW.GLFW_KEY_UNKNOWN); }

    @Override
    public void onTick() {
        var p = mc.player;
        if (mc.currentScreen != null || p.getAttackCooldownProgress(0.5f) < charge.f()) return;
        if (mc.crosshairTarget instanceof EntityHitResult hit
                && Targets.valid(hit.getEntity(), players.value, mobs.value, animals.value)) {
            mc.interactionManager.attackEntity(p, hit.getEntity());
            p.swingHand(Hand.MAIN_HAND);
        }
    }
}
