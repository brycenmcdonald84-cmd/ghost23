package dev.ghost;

public enum Category {
    COMBAT("Combat"), MOVEMENT("Movement"), PLAYER("Player"), RENDER("Render");
    public final String label;
    Category(String label) { this.label = label; }
}
