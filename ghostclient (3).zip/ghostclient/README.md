# Ghost Client 2.0 (Fabric, MC 1.21.11)

RIGHT SHIFT opens the menu. Left click a module to toggle, right click to open its settings,
click settings to change them (click a slider to set the value, click a mode to cycle it).
Settings are saved to config/ghost.json when you close the menu.
Default keys: K KillAura | R Sprint | V Speed | G Flight | N NoFall | B Fullbright.
All keys are rebindable in Options > Controls > Key Binds > Ghost Client.
